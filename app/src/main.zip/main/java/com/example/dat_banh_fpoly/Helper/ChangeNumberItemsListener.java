package com.example.dat_banh_fpoly.Helper;

public interface ChangeNumberItemsListener {
    void onChanged();
}

