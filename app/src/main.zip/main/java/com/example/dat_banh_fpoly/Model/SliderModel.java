package com.example.dat_banh_fpoly.Model;

public class SliderModel {
    private String url;
    public SliderModel(){

    }
    public SliderModel(String url){
        this.url = url;
    }
    public String getUrl(){
        return url;
    }
    public void setUrl(String url){
        this.url = url;
    }
}
